const int led1Pin = 8;
const int led2Pin = 9;

void setup() {
  pinMode(led1Pin, OUTPUT);
  pinMode(led2Pin, OUTPUT);
}

void loop() {
  digitalWrite(led1Pin, HIGH);
  digitalWrite(led2Pin, LOW);
  delay(1500); 

  digitalWrite(led1Pin, LOW);
  digitalWrite(led2Pin, HIGH);
  delay(1500); 
}
